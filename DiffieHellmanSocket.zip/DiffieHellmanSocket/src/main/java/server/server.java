package server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;

class User_A
{
    public int q;
    public int alpha;
    public int Ya;
    public int Yb;
    private int Xa;
    private int key;
    
    User_A()
    {
        Xa=0;
    }
    User_A(int a)
    {
        Xa=a;
    }
    
    public void public_private_key_generation() throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        
            /*1. Selecting Global Public Element*/
            System.out.println("Enter a Public Value for User A (prime number):");
            q=Integer.parseInt(br.readLine());
        
            System.out.print("Enter primitive root of "+q+":");
            alpha=Integer.parseInt(br.readLine());
        
            /*2. User A Key Generation*/
            System.out.println("Enter User A's Private Key (less than "+q+"):");
            //Xa is User A's Private key
            Xa=Integer.parseInt(br.readLine());
            //Ya=alpha^Xa mod q
            double dYa=Math.pow(alpha,Xa)%q;
            //Ya is User A's Public key
            Ya=(int)dYa;
            System.out.println("Ya="+Ya);
    }
    
    public  void generating_secret_key(DataInputStream din,DataOutputStream dout) throws IOException 
    {
        //sending the generated Public key to User B
        dout.writeInt(Ya);
        dout.flush();
        
        /*4. Calculation of Secret key by User A*/
        Yb =din.readInt();
        System.out.println("public key of User B="+Yb);
        //k=(Yb)^Xa mod q
        double dKa=Math.pow(Yb,Xa)%q;
        //key is the Secret key by User A
        key=(int)dKa;
        System.out.println("Key calculated at User A's side:"+key);
    }
}

public class server {
    public static void main(String[] args) {
        System.out.println("User A");
        try{
            User_A a=new User_A();
            a.public_private_key_generation();
            
            ServerSocket ss=new ServerSocket(9090);
            Socket s=ss.accept();
            
            DataInputStream din=new DataInputStream(s.getInputStream());
            DataOutputStream dout=new DataOutputStream(s.getOutputStream());
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            a.generating_secret_key(din,dout);
            System.out.println("Key Successfully shared.");
            String msgin="",msgout="";
            while(!msgin.endsWith("end")){
                msgin=din.readUTF();
                System.out.println(msgin);
                msgout=br.readLine();
                dout.writeUTF(msgout);
                dout.flush();
            }
            s.close();
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }
}

