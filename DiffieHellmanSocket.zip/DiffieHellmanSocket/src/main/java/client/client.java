package client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

class User_B
{
    public int q;
    public int alpha;
    public int Ya;
    public int Yb;
    private int Xb;
    private int key;
    
    User_B()
    {
        Xb=0;
    }
    User_B(int a)
    {
        Xb=a;
    }
    
    public void public_private_key_generation() throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        
                /*1. Selecting Global Public Element*/
                System.out.println("Enter a Public Value for User B (prime number):");
                q=Integer.parseInt(br.readLine());
        
                System.out.print("Enter primitive root of "+q+":");
                alpha=Integer.parseInt(br.readLine());
                
                /*3. User B Key Generation*/
                System.out.println("Enter User B's Private Key (less than "+q+"):");
                //Xb is User B's Private key
                Xb=Integer.parseInt(br.readLine());
                //Yb=alpha^Xb mod q
                double dYb=Math.pow(alpha,Xb)%q;
                //Yb is User B's Public key
                Yb=(int)dYb;
                System.out.println("Yb="+Yb);
    }
    
    public  void generating_secret_key(DataInputStream din,DataOutputStream dout) throws IOException
    {
        /*5. Calculation of Secret key by User B*/
        Ya=din.readInt();
        System.out.println("public key of User A="+Ya);
        
        //sending the generated Public key to User A
        dout.writeInt(Yb);
        dout.flush();
        //k=(Ya)^Xb mod q
        double dKb=Math.pow(Ya,Xb)%q;
        //key is the Secret key by User B
        key=(int)dKb;
        System.out.println("Key calculated at User B's side:"+key);
    }
}

public class client {

    public static void main(String[] args) {
        System.out.println("User B");
        try{
            User_B b=new User_B();
            b.public_private_key_generation();
            Socket s=new Socket("127.0.0.1",9090);
            
            DataInputStream din=new DataInputStream(s.getInputStream());
            DataOutputStream dout=new DataOutputStream(s.getOutputStream());
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            b.generating_secret_key(din,dout);
            System.out.println("Key Successfully shared.");
            String msgin="",msgout="";
            while(!msgin.endsWith("end")){
                msgout=br.readLine();
                dout.writeUTF(msgout);
                msgin=din.readUTF();
                System.out.println(msgin);
            }
            s.close();
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
